package com.dale.todo;
final class VoiceInput { static String clean(String raw){if(raw==null)return "";String s=raw.trim();return s.length()>2000?s.substring(0,2000):s;} }
