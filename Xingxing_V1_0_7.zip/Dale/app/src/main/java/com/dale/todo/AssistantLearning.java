package com.dale.todo;
import java.util.regex.*;
final class AssistantLearning {
 static String teaching(String s){Matcher m=Pattern.compile("^(?:请)?(?:你)?(?:记住[，,:： ]*|以后|今后)(.+)$").matcher(s.trim());return m.matches()?m.group(1).trim():"";}
 static String clarify(String s){if(s.matches(".*(删|取消|不要|清空).*"))return "你想删除哪项任务，还是某一天的全部任务？";if(s.matches(".*(改|推迟|提前).*"))return "你想修改哪项任务，改成什么？";if(s.matches(".*(重要|事情|任务|待办).*"))return "具体要做什么事情？";if(s.matches(".*(安排|计划).*"))return "你想安排哪一天，主要做哪些事情？";return "我还不确定你的意思。你可以告诉我具体要做什么、哪一天做，或者要修改哪项任务。";}
 static String combine(String previous,String next){return previous.trim()+"，补充说明："+next.trim();}
 static String category(String task,String rule){Matcher m=Pattern.compile("^(.+?)(?:都)?(?:属于|归为|归入|分类为|归类为)(.+?)[。！]?$" ).matcher(rule);if(!m.matches())return "";String category=CategoryLogic.normalize(m.group(2).trim());if(CategoryLogic.index(category)<0)return "";for(String k:m.group(1).replaceFirst("^(?:我说|以后)","").split("[、，,]|和|以及")){k=k.trim();if(!k.isEmpty()&&task.contains(k))return category;}return "";}
}
