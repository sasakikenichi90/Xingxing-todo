package com.dale.todo;
final class CalendarCommand {
 final String op, task;
 private CalendarCommand(String o,String t){op=o;task=t;}
 static boolean reserved(String s){return s!=null && s.trim().startsWith("星星");}
 static CalendarCommand parse(String s){if(!reserved(s))return null;s=s.trim().substring(2).replaceFirst("^[：:，,\\s]+", "");
 for(String op:new String[]{"确认今日计划","生成今日总结","查询今日任务","添加","完成","恢复","顺延","重要","普通","取消"}){if(!s.startsWith(op))continue;String t=s.substring(op.length()).trim();if(op.endsWith("计划")||op.endsWith("总结")||op.endsWith("任务")){if(t.isEmpty())return new CalendarCommand(op,"");}else if(!t.isEmpty()&&t.length()<=200)return new CalendarCommand(op,t);}
 return null;}
}
