package com.dale.todo;
import org.json.JSONObject;
final class CategoryColors {
 static final int[] PALETTE=CategoryLogic.COLORS;
 static int index(String n){int i=CategoryLogic.index(n);return i<0?5:i;}
 static int color(JSONObject o){String n=o.optString("category");int i=CategoryLogic.index(n);return i>=0?PALETTE[i]:o.optInt("categoryColor",PALETTE[5]);}
 static int background(JSONObject o){int c=color(o);return 0xff000000|((255*90+((c>>16)&255)*10)/100<<16)|((255*90+((c>>8)&255)*10)/100<<8)|((255*90+(c&255)*10)/100);}
}
