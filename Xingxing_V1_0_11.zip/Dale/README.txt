星星·每日计划 V1.0.9
独立 applicationId: com.xingxing.todo
Java namespace 保持原值以兼容 JNI。
使用 XINGXING_SIGNING，PKCS12 alias xingxing，格式 password:base64。
奖励按日期轮换，不新增积分机制。
