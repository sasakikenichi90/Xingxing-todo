package com.dale.todo;
final class StarRewardRotation {
 static int index(String d){try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.ROOT);f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));f.setLenient(false);return (int)Math.floorMod(Math.floorDiv(f.parse(d).getTime(),86400000L),14L);}catch(Exception e){return 0;}}
}
